/**
  Generated Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This is the main file generated using PIC10 / PIC12 / PIC16 / PIC18 MCUs

  Description:
    This header file provides implementations for driver APIs for all modules selected in the GUI.
    Generation Information :
        Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.81.7
        Device            :  PIC16F15354
        Driver Version    :  2.00
*/

/*
    (c) 2018 Microchip Technology Inc. and its subsidiaries. 
    
    Subject to your compliance with these terms, you may use Microchip software and any 
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party 
    license terms applicable to your use of third party software (including open source software) that 
    may accompany Microchip software.
    
    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER 
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY 
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS 
    FOR A PARTICULAR PURPOSE.
    
    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP 
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO 
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL 
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT 
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS 
    SOFTWARE.
*/

#include "mcc_generated_files/mcc.h"
#include "stdlib.h"
#include <string.h>

#define U1_EN()         (BAUD1CON = 0xB0)
#define U1_DIS()        (BAUD1CON = 0x80)
#define U2_EN()         (BAUD2CON = 0xB0)
#define U2_DIS()        (BAUD2CON = 0x80)
#define GPS_Start()     do { LATAbits.LATA0 = 1; } while(0)
#define GPS_Stop()      do { LATAbits.LATA0 = 0; } while(0)

volatile int Sw_f = 1;          // Button interrupt flag
volatile int GPS_f = 1;         // UART interrupt flag
uint8_t rxData1;
uint8_t rxData2;
char *GLL = "$PMTK314,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0*29\r\n";


char    GPS_data[50];  // Array for raw GPS data
char * lat;      // Array for parsed longitude
char * lon;      // Array for parsed longitude
char str[100];
//const char * tokc = ',';
//const char * tokp = '.';
/* Variable for incrementing outside of for loops */
int i = 0;


void GPS_Read(void)
{
    while (EUSART1_Read() != 0x24);
    while(!EUSART1_DataReady);// Wait for new line to come in over UART
    for (int i=0; i<=50; i++)   //Read one line UART to GPS_data
    {
        GPS_data[i] = EUSART1_Read();
    }
    //U1_DIS();               // Disable UART3 to prevent further interrupts
}
void main(void){
SYSTEM_Initialize();    // See following comment
EUSART1_Initialize();
GPS_Start();
INTERRUPT_GlobalInterruptEnable();

//----------------------------------------------------------------------------//
while (1){
    /* Verify program running with 1Hz blinking LED*/
    LED_0_Toggle();
    __delay_ms(1000);
    if (Sw_f == 1){     /* If statement #1: Enable UART*/
        U1_EN();
        EUSART1_Write(GLL);
        /*EUSART1_Write(0xB5);
        __delay_ms(100);
        EUSART1_Write(0x62);
        __delay_ms(100);
        EUSART1_Write(0x06);
        __delay_ms(100);
        EUSART1_Write(0x01);
        __delay_ms(100);
        EUSART1_Write(2);
        __delay_ms(100);
        EUSART1_Write(0xF0);
        __delay_ms(100);
        EUSART1_Write(0x08);
        __delay_ms(100);

        EUSART1_Write(0xB5 + 0x62 + 0x06 + 0x01 + 8 + 0xF0 + 0x08);*/


        
        Sw_f = 0;       // Reset flag
    }
    
    if (GPS_f == 1){    // If statement # 2: Read UART3, Parse, Write UART1
        GPS_Read();
        EUSART2_Write(GPS_Read);
        printf(GPS_Read);
        
//----------------------------------------------------------------------------//
       
    }
}   // while(1)
}   //void main
/**
 End of File
*/

