/**
  Generated Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This is the main file generated using PIC10 / PIC12 / PIC16 / PIC18 MCUs

  Description:
    This header file provides implementations for driver APIs for all modules selected in the GUI.
    Generation Information :
        Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.81.7
        Device            :  PIC16F15354
        Driver Version    :  2.00
*/

/*
    (c) 2018 Microchip Technology Inc. and its subsidiaries. 
    
    Subject to your compliance with these terms, you may use Microchip software and any 
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party 
    license terms applicable to your use of third party software (including open source software) that 
    may accompany Microchip software.
    
    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER 
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY 
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS 
    FOR A PARTICULAR PURPOSE.
    
    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP 
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO 
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL 
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT 
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS 
    SOFTWARE.
*/

#include "mcc_generated_files/mcc.h"

// Timing - 32Mhz
#define send(b) LATBbits.LATB5 = 1; NOP(); LATBbits.LATB5 = b; NOP(); LATBbits.LATB5 = 0; NOP(); NOP();

// Number of LEDs in the string
int numLEDs = 39;

uint8_t byte;
int LEDon = 0;

// output entire byte(8) to the LED 
void sendByte(unsigned char b)
{
    if(b & 0b10000000){send(1);} // bitwise add, top bit b set & top bit __ set, output one pulse
    else{send(0);} // if k = 0 (not set), will output zero pulse
    
    if(b & 0b01000000){send(1);}
    else{send(0);}
    
    if(b & 0b00100000){send(1);}
    else{send(0);}
    
    if(b & 0b00010000){send(1);}
    else{send(0);}
    
    if(b & 0b000010000){send(1);}
    else{send(0);}
    
    if(b & 0b00000100){send(1);}
    else{send(0);}
    
    if(b & 0b00000010){send(1);}
    else{send(0);}
    
    if(b & 0b00000001){send(1);}
    else{send(0);}
}

void sendRGB(unsigned char g, unsigned char r, unsigned char b)
{
    sendByte(g); // green
    sendByte(r); // red
    sendByte(b); // blue
}

void red(void)
{
    sendRGB(0,32,0);
}

void yellow(void)
{
    sendRGB(32,32,0);
}

void green(void)
{
    sendRGB(32,0,0);
}

void blue(void)
{
    sendRGB(0,0,32);
}

void cyan(void)
{
    sendRGB(32,0,32);
}

void white(void)
{
    sendRGB(32,32,32);
}

// Clears single LED
void clear(void) 
{
    sendRGB(0,0,0);
}

// Clears all LEDs
void clearAll(void) 
{ 
    for(int i = 0; i <= numLEDs; i++)
    {
        sendRGB(0,0,0);
    }
}

void playSound(void)
{
    for(int i = 0; i < 3; i++)
    {
        for(int i = 0; i < 200; i++)
        {
            BUZZER_SetHigh();
            __delay_ms(1);
            BUZZER_SetLow();
            __delay_ms(1);
        }
        __delay_ms(1000);
    }
}

void EUSART1_Receive_CISR(void)
{
    EUSART1_Receive_ISR();
    while(!EUSART1_is_rx_ready());
    byte = EUSART1_Read();
    
    if(byte == 'b'){
        playSound();
    }
    
    if(byte == 'c'){
        LEDon = 1;
    }
    
    if(byte == 'o'){
        LEDon = 0;
    }
    
    if(byte == 'g'){
        printf("33.3060N 111.6785W\r\n");
    }
}

void main(void)
{
    SYSTEM_Initialize();
    
    EUSART1_SetRxInterruptHandler(EUSART1_Receive_CISR);
    
    // Enable global interrupts
    INTERRUPT_GlobalInterruptEnable();
    // Enable peripheral interrupts
    INTERRUPT_PeripheralInterruptEnable();
    
    ADC_Initialize(); // Temperature Sensor Initialization
    ADC_SelectChannel(TMP_1);
    ADC_StartConversion;
    adc_result_t convertedValue = 0; // Converted ADC value

    while (1)
    {
        // Add your application code
        convertedValue = (ADC_GetConversion(TMP_1))*10;
        
        float mV = (convertedValue*(3300/1024));
        float tmpC = mV/15;
        float tmpF = (tmpC*9)/5;
        
        if(tmpF >= 65)
        {
            printf("Overheating.\r\n");
        }
        
        if(LEDon == 1)
        {
            // LED pattern
            for(int n = 0; n <= numLEDs; n++)
            {
                red();
            }
            __delay_ms(400);

            for(int n = 0; n <= numLEDs; n++)
            {
                blue();
            }
            __delay_ms(200);
        }
        else
        {
            clearAll();
        }
    }
}
/**
 End of File
*/