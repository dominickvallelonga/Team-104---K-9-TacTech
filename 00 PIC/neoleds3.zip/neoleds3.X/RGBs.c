/*
 * File:   RGBs.c
 * Author: adria
 *
 * Created on April 18, 2022, 3:55 PM
 */

#include "mcc_generated_files/mcc.h"
#include "RGBs.h"


// output entire byte(8) to the LED 
void sendByte(unsigned char b)
{
    if(b & 0b10000000){send(1);} //bitwise add, top bit b set & top bit __ set, output one pulse
    else{send(0);} // if k = 0 (not set), will output zero pulse
    
    if(b & 0b01000000){send(1);}
    else{send(0);}
    
    if(b & 0b00100000){send(1);}
    else{send(0);}
    
    if(b & 0b00010000){send(1);}
    else{send(0);}
    
    if(b & 0b000010000){send(1);}
    else{send(0);}
    
    if(b & 0b00000100){send(1);}
    else{send(0);}
    
    if(b & 0b00000010){send(1);}
    else{send(0);}
    
    if(b & 0b00000001){send(1);}
    else{send(0);}
}

void sendRGB(unsigned char g, unsigned char r, unsigned char b)
{
    sendByte(g); //green
    sendByte(r); //red
    sendByte(b); //blue
}

void red(void)
{
    sendRGB(0,32,0);
}

void yellow(void)
{
    sendRGB(32,32,0);
}

void green(void)
{
    sendRGB(32,0,0);
}

void blue(void)
{
    sendRGB(0,0,32);
}

void cyan(void)
{
    sendRGB(32,0,32);
}

void white(void)
{
    sendRGB(32,32,32);
}

// Clears single LED
void clear(void) 
{
    sendRGB(0,0,0);
}

// Clears all LEDs
void clearAll(void) 
{ 
    for(int i = 0; i <= numLEDs; i++)
    {
        sendRGB(0,0,0);
    }
}
